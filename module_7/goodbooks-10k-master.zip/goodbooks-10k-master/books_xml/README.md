## Books XML

The archive contains 10000 XML files. One of them is available as **books_xml/sample_book.xml**.
