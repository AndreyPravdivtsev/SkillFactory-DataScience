# contrib

Besides the Philipp Spachtholz' notebook here, check out [Lit2Vec](https://github.com/Santosh-Gupta/Lit2Vec) by Santosh Gupta. 
It's about _representing books as vectors using the Word2Vec algorithm_ and it has many TSNE book similarity maps.
